package com.yazdanparast.sajjad.miniature;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    //INSTRUCTIONS
    //R_TYPE
    private final String ADD = "0000";
    private final String NAND = "0100";
    private final String OR = "0011";
    private final String SLT = "0010";
    private final String SUB = "0001";
    //I_TYPE
    private final String ADDI ="0101";
    private final String BEQ ="1011";
    private final String JARL ="1100";
    private final String LUI ="1000";
    private final String LW ="1001";
    private final String ORI ="0111";
    private final String SLTI ="0110";
    private final String SW ="1010";
    //J_TYPE
    private final String HALT ="1110";
    private final String J ="1101";


    //MEMORY
    private List<Integer> registers;


    //POINTERS
    private int PC = 0 ;

    //WIDGETS
    private ImageView newFile_btn, saveFile_btn;
    private TextView fileName_tv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);
        if(getSupportActionBar()!=null)
        {
            this.getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setCustomView(R.layout.custom_actionbar);
        }
        actionBarHandler();
        init();
    }

    private void init() {
        registers = new ArrayList<>();
    }


    private void actionBarHandler() {
        if(getSupportActionBar()!=null)
        {
           View view = getSupportActionBar().getCustomView();
           newFile_btn = view.findViewById(R.id.new_file_btn);
           saveFile_btn = view.findViewById(R.id.save_file_btn);
           fileName_tv = view.findViewById(R.id.file_name_tv);

           newFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "New button has been clicked", Toast.LENGTH_LONG).show();
               }
           });

           saveFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "Save button has been clicked", Toast.LENGTH_LONG).show();
               }
           });
        }
    }

}
