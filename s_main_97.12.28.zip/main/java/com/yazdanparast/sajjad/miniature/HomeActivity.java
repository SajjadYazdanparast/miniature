package com.yazdanparast.sajjad.miniature;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {

    ImageView newFile_btn, saveFile_btn;
    TextView fileName_tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);
        if(getSupportActionBar()!=null)
        {
            this.getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setCustomView(R.layout.custom_actionbar);
        }
        actionBarHandler();
    }

    private void actionBarHandler() {
        if(getSupportActionBar()!=null)
        {
           View view = getSupportActionBar().getCustomView();
           newFile_btn = view.findViewById(R.id.new_file_btn);
           saveFile_btn = view.findViewById(R.id.save_file_btn);
           fileName_tv = view.findViewById(R.id.file_name_tv);

           newFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "New button has been clicked", Toast.LENGTH_LONG).show();
               }
           });

           saveFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "Save button has been clicked", Toast.LENGTH_LONG).show();
               }
           });
        }
    }

}
