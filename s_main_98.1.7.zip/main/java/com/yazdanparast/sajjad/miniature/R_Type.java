package com.yazdanparast.sajjad.miniature;

public class R_Type {
    public String firstUnused ;  //4bits
    public String opcode ;  //4bits
    public String rs ;      //4bits
    public String rt ;      //4bits
    public String rd ;      //12bits
    public String secondUnused ;
    public R_Type(){
        this.firstUnused="0000";
        this.opcode="0000";
        this.rs="0000";
        this.rt="0000";
        this.rd="0000";
        this.secondUnused="000000000000";
    }

    public R_Type(String opcode, String rs, String rt, String rd) {
        this.opcode = opcode;
        this.rs = rs;
        this.rt = rt;
        this.rd = rd;
    }

    @Override
    public String toString() {

        return this.firstUnused+" "+this.opcode+" "
                +this.rs+" "+this.rt+" "+this.rd+" "
                +this.secondUnused+'\n';
    }
}
