package com.yazdanparast.sajjad.miniature;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{

    //INSTRUCTIONS
    //R_TYPE
    private final String ADD = "0000";
    private final String ADDNAME = "add";
    private final String NAND = "0100";
    private final String NANDNAME = "nand";
    private final String OR = "0011";
    private final String ORNAME = "or";
    private final String SLT = "0010";
    private final String SLTNAME = "slt";
    private final String SUB = "0001";
    private final String SUBNAME = "sub";
    //I_TYPE
    private final String ADDI ="0101";
    private final String ADDINAME = "addi";
    private final String BEQ ="1011";
    private final String BEQNAME = "beq";
    private final String JARL ="1100";
    private final String JARLNAME ="jarl";
    private final String LUI ="1000";
    private final String LUINAME = "lui";
    private final String LW ="1001";
    private final String LWNAME = "lw";
    private final String ORI ="0111";
    private final String ORINAME = "ori";
    private final String SLTI ="0110";
    private final String SLTINAME = "slti";
    private final String SW ="1010";
    private final String SWNAME = "sw";
    //J_TYPE
    private final String HALT ="1110";
    private final String HALTNAME = "halt";
    private final String J ="1101";
    private final String JNAME = "j";


    //OUTPUT
    String assemblied_code ;

    //MEMORY
    private List<Integer> registers;
    private List<String> labels;
    //POINTERS
    private int PC = 0 ;

    //WIDGETS
    private ImageView newFile_btn, saveFile_btn;
    private TextView fileName_tv;
    private ImageButton run_btn ;
    private EditText text_editor_et ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);
        if(getSupportActionBar()!=null)
        {
            this.getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
            getSupportActionBar().setDisplayShowCustomEnabled(true);
            getSupportActionBar().setCustomView(R.layout.custom_actionbar);
        }
        actionBarHandler();
        init();
        textEditorHandler();
    }

    private void textEditorHandler() {
        text_editor_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                Toast.makeText(HomeActivity.this, charSequence, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void init() {
        assemblied_code = "";
        registers = new ArrayList<>();
        labels = new ArrayList<>();
        run_btn = findViewById(R.id.run_btn);
        run_btn.setOnClickListener(this);
        text_editor_et = findViewById(R.id.text_editor_et);
    }

    private void actionBarHandler() {
        if(getSupportActionBar()!=null)
        {
           View view = getSupportActionBar().getCustomView();
           newFile_btn = view.findViewById(R.id.new_file_btn);
           saveFile_btn = view.findViewById(R.id.save_file_btn);
           fileName_tv = view.findViewById(R.id.file_name_tv);

           newFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "New button has been clicked", Toast.LENGTH_LONG).show();
               }
           });

           saveFile_btn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   Toast.makeText(HomeActivity.this, "Save button has been clicked", Toast.LENGTH_LONG).show();
               }
           });
        }
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case R.id.run_btn :
            {
                String code = text_editor_et.getText().toString().trim();
                executing(code);
            }
                break;
            case R.id.new_file_btn :
            {

            }
                break;
            case R.id.save_file_btn :
            {

            }
                break;
        }
    }

    private void executing(String code) {
        String[] whole_code = code.split("\n");
        List<String[]> all_lines = new ArrayList<>();
        String[] line;
        for (String s : whole_code) {
            s = s.trim();
            StringBuilder sb =new StringBuilder(s);
            sb.delete(sb.lastIndexOf("#"), sb.length());
            s=sb.toString();
            line = s.split(" ");
            for (int i = 0; i < line.length; i++) {
                line[i] = line[i].trim();
                line[i] = line[i].toLowerCase();
            }
            all_lines.add(line);
        }
        for (int i = 0; i < all_lines.size(); i++) {
            switch (all_lines.get(i)[0]) {
                case ADDNAME: {
                    R_type_handler(all_lines.get(i), ADD,false);
                }
                break;
                case NANDNAME: {
                    R_type_handler(all_lines.get(i), NAND,false);
                }
                break;
                case ORNAME: {
                    R_type_handler(all_lines.get(i), OR,false);
                }
                break;
                case SLTNAME: {
                    R_type_handler(all_lines.get(i), SLT,false);
                }
                break;
                case SUBNAME: {
                    R_type_handler(all_lines.get(i), SUB,false);
                }
                break;
                case ADDINAME: {

                }
                break;
                case BEQNAME: {

                }
                break;
                case JARLNAME: {

                }
                break;
                case LUINAME: {

                }
                break;
                case LWNAME: {

                }
                break;
                case ORINAME: {

                }
                break;
                case SLTINAME: {

                }
                break;
                case SWNAME: {

                }
                break;
                case HALTNAME: {

                }
                break;
                case JNAME: {

                }
                break;
                default: {
                    if (labels.contains(all_lines.get(i)[0])){
                        Toast.makeText(this, "Duplicated label", Toast.LENGTH_LONG).show();
                    }
                    labels.add(all_lines.get(i)[0]);
                    switch (all_lines.get(i)[1]) {
                        case ADDNAME: {
                            R_type_handler(all_lines.get(i), ADD,true);
                        }
                        break;
                        case NANDNAME: {

                        }
                        break;
                        case ORNAME: {

                        }
                        break;
                        case SLTNAME: {

                        }
                        break;
                        case SUBNAME: {

                        }
                        break;
                        case ADDINAME: {

                        }
                        break;
                        case BEQNAME: {

                        }
                        break;
                        case JARLNAME: {

                        }
                        break;
                        case LUINAME: {

                        }
                        break;
                        case LWNAME: {

                        }
                        break;
                        case ORINAME: {

                        }
                        break;
                        case SLTINAME: {

                        }
                        break;
                        case SWNAME: {

                        }
                        break;
                        case HALTNAME: {

                        }
                        break;
                        case JNAME: {

                        }
                        break;
                        default: {
                            Toast.makeText(this, "Not such instruction found !", Toast.LENGTH_LONG).show();
                        }
                    }

                }
            }
        }
    }
    private void R_type_handler(String[] arrayString,String opcode_name,boolean hasLabel) {
        R_Type ins = new R_Type();
        ins.opcode=opcode_name;
        if (hasLabel)
        {
            if(arrayString.length<3)
            {
                //error
                Toast.makeText(this, "Incorrect instructions !", Toast.LENGTH_LONG).show();
                return ;
            }
            String [] registers = arrayString[2].split(",");
            ins.rd=registers[0];
            ins.rs=registers[1];
            ins.rt=registers[2];
        }
        else
        {
            if(arrayString.length<2)
            {
                //error
                Toast.makeText(this, "Incorrect instructions !", Toast.LENGTH_LONG).show();
                return ;
            }
            String [] registers = arrayString[1].split(",");
            ins.rd=registers[0];
            ins.rs=registers[1];
            ins.rt=registers[2];
        }

    }
}
