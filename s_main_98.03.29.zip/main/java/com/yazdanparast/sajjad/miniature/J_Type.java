package com.yazdanparast.sajjad.miniature;

import android.widget.Toast;

import java.math.BigInteger;

public class J_Type {
    String first_unused ;       //4 bits
    String opcode ;             //4 bits
    String second_unused ;      //8 bits
    String target ;             //16 bits

    public J_Type(String opcode,String target) {
        this.first_unused = "0000";
        this.opcode = opcode;
        this.second_unused = "00000000";
        this.target = target;
    }

    public J_Type() {
        this.first_unused="0000";
        this.opcode="0000";
        this.second_unused="00000000";
        this.target="0000000000000000";
    }

    @Override
    public String toString() {
        String str =  this.opcode+
                this.second_unused+HomeActivity.to_4_digit_binary_number("0000000000000000", this.target);
        str = new BigInteger(str,2).toString() ;
        str += '\n' ;
        return str ;
    }
}
