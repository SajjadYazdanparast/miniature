package com.yazdanparast.sajjad.miniature;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.TextView;

public class StatisticActivity extends AppCompatActivity {

    TextView R_type_tv, I_type_tv, J_type_tv, register_used_tv, instruction_number_tv, reference_to_ram_tv, ram_used_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_statistic);
        init();
    }

    private void init() {
        R_type_tv = findViewById(R.id.r_type_instructions);
        I_type_tv = findViewById(R.id.i_type_instructions);
        J_type_tv = findViewById(R.id.j_type_instructions);

        ram_used_tv = findViewById(R.id.ram_used);
        reference_to_ram_tv = findViewById(R.id.reference_to_ram);
        instruction_number_tv = findViewById(R.id.executed_instructions);
        register_used_tv = findViewById(R.id.register_used);

        R_type_tv.setText(String.valueOf(ResultActivity.R_type_number));
        I_type_tv.setText(String.valueOf(ResultActivity.I_type_number));
        J_type_tv.setText(String.valueOf(ResultActivity.J_type_number));

        int sajjad = 0;
        for (int aRam_used : HomeActivity.ram_used)
            if (aRam_used != 0)
                sajjad++;
        ram_used_tv.setText(String.valueOf(sajjad));
        sajjad = 0;
        for (int i = 0; i < ResultActivity.register_used.length; i++)
            if (ResultActivity.register_used[i] != 0)
                sajjad++;
        register_used_tv.setText(String.valueOf((double) sajjad * 100 / 16));

        reference_to_ram_tv.setText(String.valueOf(ResultActivity.reference_to_ram));
        instruction_number_tv.setText(String.valueOf(ResultActivity.instruction_number));
    }
}
