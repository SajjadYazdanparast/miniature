package com.yazdanparast.sajjad.miniature;

import java.math.BigInteger;

public class R_Type {

    String format = "0000" ;
    public String firstUnused ;  //4bits
    public String opcode ;  //4bits
    public String rs ;      //4bits
    public String rt ;      //4bits
    public String rd ;      //12bits
    public String secondUnused ;
    public R_Type(){
        this.firstUnused="0000";
        this.opcode="0000";
        this.rs="0000";
        this.rt="0000";
        this.rd="0000";
        this.secondUnused="000000000000";
    }

    public R_Type(String opcode, String rs, String rt, String rd) {
        this.opcode = opcode;
        this.rs = rs;
        this.rt = rt;
        this.rd = rd;
    }

    @Override
    public String toString() {

//        return this.firstUnused+" "+HomeActivity.to_4_digit_binary_number(format, this.opcode)+" "
//                +HomeActivity.to_4_digit_binary_number(format, this.rs)+" "+HomeActivity.to_4_digit_binary_number(format, this.rt)+" "
//                +HomeActivity.to_4_digit_binary_number(format, this.rd)+" "
//                +this.secondUnused+'\n';

        String str = this.opcode
                +HomeActivity.to_4_digit_binary_number(format, this.rs)+HomeActivity.to_4_digit_binary_number(format, this.rt)
                +HomeActivity.to_4_digit_binary_number(format, this.rd)
                +this.secondUnused;

        str = new BigInteger(str,2).toString();
        str+='\n' ;

        return str ;
//        return  this.firstUnused+" "+this.opcode+" "+this.rs+" "+this.rt+" "+this.rd+" "+this.secondUnused+'\n';
    }

}
