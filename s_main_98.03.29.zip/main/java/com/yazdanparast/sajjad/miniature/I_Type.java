package com.yazdanparast.sajjad.miniature;

import java.math.BigInteger;

public class I_Type {
    public String unused ;     //4bits
    public String opcode ;      //4bits
    public String rs ;          //4bits
    public String rt ;          //4bits
    public String offset ;      //16bits;

    public I_Type() {
        this.unused="0000";
        this.opcode="0000";
        this.rs="0000";
        this.rt="0000";
        this.offset="0000000000000000";
    }

    public I_Type(String opcode, String rs, String rt, String offset) {
        this.opcode = opcode;
        this.rs = rs;
        this.rt = rt;
        this.offset = offset;
    }

    @Override
    public String toString() {
//        if (this.opcode == "1011")
//        {
//            String str = HomeActivity.to_4_digit_binary_number("0000", this.opcode)
//                    + HomeActivity.to_4_digit_binary_number("0000", this.rt) + HomeActivity.to_4_digit_binary_number("0000", this.rs)
//                    + HomeActivity.to_4_digit_binary_number("0000000000000000", this.offset);
//            str = new BigInteger(str ,2).toString()  ;
//            str += '\n' ;
//            return str ;
//        }

        String str =  this.opcode+
        HomeActivity.to_4_digit_binary_number("0000", this.rs)+ HomeActivity.to_4_digit_binary_number("0000", this.rt)
                + HomeActivity.to_4_digit_binary_number("0000000000000000", this.offset);
        str = new BigInteger(str ,2).toString()  ;
        str += '\n' ;
        return str ;

    }
}
