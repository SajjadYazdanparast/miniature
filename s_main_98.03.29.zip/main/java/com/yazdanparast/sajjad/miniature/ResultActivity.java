package com.yazdanparast.sajjad.miniature;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.math.BigInteger;
import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    //statistics
    static int R_type_number , I_type_number , J_type_number ;
    static int []  register_used ;
    static int instruction_number ;
    static int reference_to_ram;



    int pc;
    int directive_instruction_size ;
    int MAX_PC ;
    String[] registerList;
    String [] ram ;
    ArrayList<String> decode_str;

    TextView[] registerView ;
    TextView result_tv;
    Button pc_btn;
    Button statistics_btn;
    Button show_register_list;
    LinearLayout register_listview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_result);
        init();
        Bundle bundle = getIntent().getExtras();
        result_tv = findViewById(R.id.result_tv);

        if (bundle != null && bundle.containsKey("result") && bundle.containsKey("directive_size")) {
            result_tv.setText(bundle.getString("result"));
            int directive_size = bundle.getInt("directive_size") ;
            String [] str = result_tv.getText().toString().split("\\n");
            for (int i =directive_size;i<str.length;i++)
            {
                decode_str.add(str[i]) ;
            }
            MAX_PC = decode_str.size()- 1;
            pc = 0;
        }

        pc_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pc <0 || pc > MAX_PC)
                {
                    error_handler(ResultActivity.this, "Program reached the end!");
                    pc_btn.setEnabled(false);
                    return;
                }
                Decode(pc);
                instruction_number++;
                pc++;
                showRegisters();
            }
        });

        statistics_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ResultActivity.this,StatisticActivity.class) );
            }
        });

        show_register_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (show_register_list.getText().toString().equals("SHOW REGISTERS"))
                {
                    register_listview.setVisibility(View.VISIBLE);
                    show_register_list.setText("HIDE REGISTERS");
                }
                else
                {
                    register_listview.setVisibility(View.GONE);
                    show_register_list.setText("SHOW REGISTERS");
                }
            }
        });

    }

    private void showRegisters() {
        for (int i=0 ;i<16;i++)
        {
            registerView[i].setText(registerList[i]);
        }
    }

    private void init() {
        R_type_number = 0;
        I_type_number = 0;
        J_type_number = 0;
        register_used =new int[16];
        for (int i=0 ;i<16 ;i++)
            register_used[i] = 0 ;
        instruction_number = 0;
        reference_to_ram = 0;
        int size = 16*1024 ;

        registerView = new TextView[16];
        String id ;
        for(int i=0 ;i<16 ;i++)
        {
            id = "reg"+i ;
            int resId = getResources().getIdentifier(id, "id", getPackageName()) ;
            registerView[i] = findViewById(resId);
        }
        directive_instruction_size =0 ;
        decode_str = new ArrayList<>() ;


        registerList = new String[16];
        for (int i=0 ;i<16 ;i++)
            registerList[i]= "00000000000000000000000000000000" ;
        pc_btn = findViewById(R.id.pc_btn);
        statistics_btn = findViewById(R.id.statistics_btn) ;
        ram = HomeActivity.ram ;

        register_listview = findViewById(R.id.register_list);
        show_register_list = findViewById(R.id.show_register_list) ;



    }

    boolean i_type_branch_operate(I_Type ins) {

//        Toast.makeText(this, "sajjad", Toast.LENGTH_LONG).show();
        //for beq ;
        if (ins.opcode.equals("1011")) {
            if (registerList[Integer.valueOf(ins.rs)].equals(registerList[Integer.valueOf(ins.rt)])) {

                pc += Integer.valueOf(ins.offset);
                if (pc < 0 || pc > MAX_PC) {
                    error_handler(this, "Program reached the end!");
                    pc_btn.setEnabled(false);
                    return false;
                }

                return true;
            }

        }

        //jalr
        if (ins.opcode.equals("1100")) {
            pc = Integer.valueOf(ins.rs);
            ins.rt = String.valueOf(pc);
            if (pc < 0 || pc > MAX_PC) {
                error_handler(this, "Invalid target address!");
                return false;
            }
            return true;
        }

        return false;
    }

    private void error_handler(Context context, String error_message) {
        if (error_message.contains("\n"))
            error_message = new StringBuilder(error_message).delete(error_message.lastIndexOf('\n'), error_message.length()).toString();
        View view = getLayoutInflater().inflate(R.layout.error_layout, null);
        final Dialog error_dialog = new Dialog(context);
        error_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        error_dialog.setContentView(view);
        error_dialog.setCancelable(false);
        ((TextView) view.findViewById(R.id.error_tv)).setText(error_message);
        (view.findViewById(R.id.back_to_code_btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                error_dialog.dismiss();
            }
        });
        error_dialog.show();
    }

    public void Decode(int pc) {


        String current_line;


//        String[] seprated = decode_str.split("\n");

        current_line = new BigInteger(decode_str.get(pc)).toString(2) ;
//        current_line = Integer.toBinaryString(Integer.valueOf(seprated[pc]));

        StringBuilder sb = new StringBuilder(current_line);
        int ss=current_line.length();
        for(int i=0;i<32-ss;i++)
            sb.insert(0 , '0');
        current_line= sb.toString();

        System.out.println("current = " + current_line );

        String opcode_temp = current_line.substring(4,8);
//        result_tv.setText(opcode_temp);
///////////R_Type//////////////////////////////////////////////////////////

        if(opcode_temp.equals("0000") ||  opcode_temp.equals("0001") ||  opcode_temp.equals("0010") ||  opcode_temp.equals("0011") ||
                opcode_temp.equals("0100"))
        {


            String rt_builder;

            //making rs
            rt_builder = current_line.substring(8 , 12);
            int tmp = Integer.parseInt(rt_builder ,2);
            rt_builder = String.valueOf(tmp);
            String rs_str = rt_builder;
            System.out.println("output=" +rs_str);


            //making rt
            rt_builder = current_line.substring(12 , 16);
            tmp = Integer.parseInt(rt_builder ,2);
            rt_builder = String.valueOf(tmp);
            String rt_str = rt_builder;
            System.out.println(rt_str);

            //making rd
            rt_builder = current_line.substring(16 , 20);
            tmp = Integer.parseInt(rt_builder ,2);
            rt_builder = String.valueOf(tmp);
            String rd_str = rt_builder;
            System.out.println(rd_str);


            R_Type RT_object = new R_Type(opcode_temp , rs_str , rt_str , rd_str);
            R_operate(RT_object);
        }

//////////////////////////I-Type////////////////////////////////////////////////

        if(opcode_temp.equals("1100")  ||opcode_temp.equals("0101") ||  opcode_temp.equals("0110") ||  opcode_temp.equals("0111") ||  opcode_temp.equals("1000") ||
                opcode_temp.equals("1001")  || opcode_temp.equals("1010") || opcode_temp.equals("1011") )
        {


            String it_builder;

            //making rs
            it_builder = current_line.substring(8 , 12);
            int tmp = Integer.parseInt(it_builder ,2);
            it_builder = String.valueOf(tmp);
            String rs_str = it_builder;
            System.out.println(rs_str);


            //making rt
            it_builder = current_line.substring(12 , 16);
            tmp = Integer.parseInt(it_builder ,2);
            it_builder = String.valueOf(tmp);
            String rt_str = it_builder;
            System.out.println(rt_str);

            //making offset
            it_builder = current_line.substring(16 , 32);
            System.out.println(it_builder);


            //////negative numbers////

            // StringBuilder it_builder_temp= new StringBuilder(it_builder);
            boolean neg=false;
            if (it_builder.charAt(0) == '1') {

                it_builder = negative_found(it_builder);
                System.out.println(it_builder);
                neg=true;
            }


            ///////////////////////////
            tmp = Integer.parseInt(it_builder ,2);
            if(neg) {
                tmp *= -1;
            }

            it_builder = String.valueOf(tmp);





            String offset_str = it_builder;


            System.out.println(offset_str);


            I_Type IT_object = new I_Type(opcode_temp , rs_str , rt_str , offset_str );

//            Toast.makeText(this, "opcode = "+opcode_temp, Toast.LENGTH_LONG).show();
            if (opcode_temp.equals("1100") || opcode_temp.equals("1011"))
                i_type_branch_operate(IT_object);
            else
                I_operate(IT_object);

        }


////////////////////////////////////J_Type//////////////////////////

        if( opcode_temp.equals("1101") || opcode_temp.equals("1110") )
        {


//            result_tv.setText("omad to if");
            String jt_builder;


            //making target
            jt_builder = current_line.substring(16 , 32);

            //////negative numbers////
            //StringBuilder jt_builder_temp= new StringBuilder(jt_builder);
            boolean neg = false;
            if (jt_builder.charAt(0) == '1') {


                jt_builder =  negative_found(jt_builder);
                neg=true;
            }


            int tmp = Integer.parseInt(jt_builder ,2);
            if(neg) {
                tmp *= -1;
            }
            jt_builder = String.valueOf(tmp);





            String target_str = jt_builder;
            System.out.println(target_str);


            J_Type JT_object = new J_Type(opcode_temp  , target_str );


            //
            J_operate(JT_object);

        }

    }

    public String negative_found(String builder) {

        StringBuilder builder_temp= new StringBuilder(builder);

        boolean first_1 = false;

        for (int i = builder.length()-1 ; i >= 0; i--) {
            if (builder_temp.charAt(i) == '0' && !first_1) {
                continue;
            }
            if (builder_temp.charAt(i) == '0' && first_1) {
                builder_temp.setCharAt(i, '1');
                continue;
            }
            if (builder_temp.charAt(i) =='1' && !first_1) {
                first_1 = true;
                continue;
            }
            if (builder_temp.charAt(i) == '1' && first_1) {
                builder_temp.setCharAt(i, '0');
                continue;
            }
        }


        return builder_temp.toString();

    }

    private String SEexpand(String s) {
        StringBuilder sb = new StringBuilder(s);
        int ss = sb.length();
        if(s.charAt(0) == '0')
            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
        else
            for(int i=0 ; i<32- ss;i++) sb.insert(0,'1');
        return sb.toString();

    }

    private int binaryStringToInt(String s) {
        if(s.length()==32) {
            if (s.charAt(0) == '0')
                return Integer.parseInt(s, 2);
            else {
                boolean b = true;
                int ss = s.length();
                StringBuilder sb = new StringBuilder(s);
                for (int i = sb.length() - 1; i >= 0; i--) {
                    if (b) {
                        if (sb.charAt(i) == '1') b = false;
                    } else {
//                        return  "15";
                        if (sb.charAt(i) == '1')     sb.setCharAt(i, '0');
                        else sb.setCharAt(i, '1');
                    }
                }
                s = sb.toString();

                return -1 * Integer.parseInt(s, 2);
            }
        }
        return Integer.parseInt(s,2);

    }

    private void R_operate(R_Type ins){
//        registerList[2] = "1010";
//        registerList[1] = "11";
        R_type_number ++ ;
        if(ins.opcode .equals( "0000"))
        {

            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int rd_index = Integer.parseInt(ins.rd);

            register_used[rs_index] ++;
            register_used[rt_index] ++;
            register_used[rd_index] ++;

            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index]) +
                    binaryStringToInt(registerList[rt_index]));
            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rd_index] = s;

        }
        else if(ins.opcode .equals( "0001"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int rd_index = Integer.parseInt(ins.rd);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            register_used[rd_index] ++;
            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index]) -
                    binaryStringToInt(registerList[rt_index]));
            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rd_index] = s;
        }
        else if(ins.opcode .equals( "0010"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int rd_index = Integer.parseInt(ins.rd);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            register_used[rd_index] ++;
            String s;
            if(binaryStringToInt(registerList[rs_index]) < binaryStringToInt(registerList[rt_index]) )
                s="1";
            else
                s="0";

            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rd_index] = s;
        }
        else if(ins.opcode .equals( "0011"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int rd_index = Integer.parseInt(ins.rd);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            register_used[rd_index] ++;
            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index]) |
                    binaryStringToInt(registerList[rt_index]));
            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rd_index] = s;
        }
        else if(ins.opcode .equals( "0100"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int rd_index = Integer.parseInt(ins.rd);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            register_used[rd_index] ++;
            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index] ) &
                    binaryStringToInt(registerList[rt_index] ));

            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            for(int i=0 ; i<sb.length();i++)
            {
                if(sb.charAt(i)=='0')  sb.setCharAt(i,'1');
                else sb.setCharAt(i,'0');
            }
            s = sb.toString();

            registerList[rd_index] = s;
        }


    }

    private void I_operate(I_Type ins){

//        Toast.makeText(ResultActivity.this, "YOUNES" +"",
//                Toast.LENGTH_LONG).show();

        I_type_number ++ ;
        if(ins.opcode .equals( "0101"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rs_index] ++;
            register_used[rt_index] ++;


            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index] ) + offset);


            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rt_index] = s;
        }
        else if(ins.opcode .equals( "0110"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rs_index] ++;
            register_used[rt_index] ++;

            String s ;
            if( binaryStringToInt(registerList[rs_index]) < offset )
                s = "1";
            else
                s= "0";

            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rt_index] = s;
        }
        else if(ins.opcode .equals("0111"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            String offset_string = Integer.toBinaryString(offset);
            if(offset<0)
                offset_string = offset_string.substring(16,32);

            String s = Integer.toBinaryString(binaryStringToInt(registerList[rs_index]) |
                    binaryStringToInt(offset_string) );

            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rt_index] = s;
        }
        else if(ins.opcode .equals( "1000"))
        {
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rt_index] ++;
            String offset_string = Integer.toBinaryString(offset);
            if(offset<0)
                offset_string = offset_string.substring(16,32);


            StringBuilder sb1 = new StringBuilder(offset_string);
            int ss1 = offset_string.length();

            for(int i=0 ; i<16- ss1;i++) sb1.insert(0,'0');
            for(int i=0;i<16 ; i++) sb1.append("0");
            String s = sb1.toString();

            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rt_index] = s;
        }
        else if(ins.opcode .equals( "1001"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            String s = ram[ offset + binaryStringToInt(registerList[rs_index]) ] ;
            reference_to_ram++;
            s = Integer.toBinaryString(Integer.parseInt(s)) ;
            StringBuilder sb = new StringBuilder(s);
            int ss = s.length();

            for(int i=0 ; i<32- ss;i++) sb.insert(0,'0');
            s = sb.toString();

            registerList[rt_index] = s;
        }
        else if(ins.opcode .equals( "1010"))
        {
            int rs_index = Integer.parseInt(ins.rs);
            int rt_index = Integer.parseInt(ins.rt);
            int offset = Integer.parseInt(ins.offset);
            register_used[rs_index] ++;
            register_used[rt_index] ++;
            ram[ offset + binaryStringToInt(registerList[rs_index]) ] = Integer.toString(
                    binaryStringToInt(registerList[rt_index]) ) ;
            HomeActivity.ram_used[ offset + binaryStringToInt(registerList[rs_index]) ] ++ ;
            reference_to_ram++;

        }


    }

    boolean J_operate(J_Type ins){               //just for j instruction{
        J_type_number++;
        if(!ins.opcode.equals("1110")) {
            pc = Integer.valueOf(ins.target);
            pc--;
            if (pc > MAX_PC) {
                error_handler(this, "Program reached the end!");
                return false;
            }
            return true;
        }
        error_handler(this, "Program reached the end!");
        pc_btn.setEnabled(false);
        return false;
    }


}