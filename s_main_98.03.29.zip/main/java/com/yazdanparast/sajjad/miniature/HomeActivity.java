package com.yazdanparast.sajjad.miniature;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    //INSTRUCTIONS
    //R_TYPE
    private final String ADD = "0000";
    private final String ADDNAME = "add";
    private final String NAND = "0100";
    private final String NANDNAME = "nand";
    private final String OR = "0011";
    private final String ORNAME = "or";
    private final String SLT = "0010";
    private final String SLTNAME = "slt";
    private final String SUB = "0001";
    private final String SUBNAME = "sub";
    //I_TYPE
    private final String ADDI = "0101";
    private final String ADDINAME = "addi";
    private final String BEQ = "1011";
    private final String BEQNAME = "beq";
    private final String JALR = "1100";
    private final String JALRNAME = "jalr";
    private final String LUI = "1000";
    private final String LUINAME = "lui";
    private final String LW = "1001";
    private final String LWNAME = "lw";
    private final String ORI = "0111";
    private final String ORINAME = "ori";
    private final String SLTI = "0110";
    private final String SLTINAME = "slti";
    private final String SW = "1010";
    private final String SWNAME = "sw";
    //J_TYPE
    private final String HALT = "1110";
    private final String HALTNAME = "halt";
    private final String J = "1101";
    private final String JNAME = "j";


    //OUTPUT
    String assembled_code;
    boolean lock_texteditor;
    boolean error_returned;
    int halt_counter;
    String error_text;
    private static final String POS_NEG_NUMERIC_REGIX = "-?\\d+(?:\\.\\d+)?";
    private static final String POSITIVE_NUMERIC_REGIX = "\\d+";
    //MEMORY
    private List<Integer> registers;
    private Map<String, Integer> labels;
    private Map<String, String> directives;
    static String [] ram = new String[16*1024] ;
    static int [] ram_used = new int[16*1024] ;
    int directive_instruction_size ;

    //POINTERS
    private int PC = 0;

    //WIDGETS
    public View custom_actionBar;
    private EditText fileName_tv;
    private Button read_file_btn;
    private ImageButton run_btn;
    static public EditText text_editor_et;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home);

        Toolbar customView = findViewById(R.id.custom_actionbar);
        setSupportActionBar(customView);

        init();
        actionBarHandler();
    }


    private void init() {
        directive_instruction_size = 0 ;
        assembled_code = "";
        error_text = "";
        halt_counter = 0;
        error_returned = false;
        registers = new ArrayList<>();
        for (int i = 0; i < 16; i++)
            registers.add(0);
        int sizze = 16*1024 ;
        for (int i=0 ;i<sizze ;i++) {
            ram[i] = "0";
            ram_used[i] = 0 ;
        }
        labels = new HashMap<>();
        directives = new HashMap<>();
        run_btn = findViewById(R.id.run_btn);
        run_btn.setOnClickListener(this);
        text_editor_et = findViewById(R.id.text_editor_et);
    }

    private void actionBarHandler() {
        custom_actionBar = findViewById(R.id.custom_actionbar);
        fileName_tv = custom_actionBar.findViewById(R.id.file_name_tv);
        read_file_btn = custom_actionBar.findViewById(R.id.custom_action_bar_btn);
        read_file_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String path = fileName_tv.getText().toString().trim();
                readFile(path);
            }
        });

    }

    private void readFile(String path) {
        File f = new File(Environment.getExternalStorageDirectory(), "Miniature");
        if (!f.exists()) {
            Toast.makeText(this, "Not such file found", Toast.LENGTH_LONG).show();
            return;
        }
        File subFile = new File(f, path);
        if (!subFile.exists()) {
            Toast.makeText(this, "Not such file found", Toast.LENGTH_LONG).show();
            return;
        }
        File main_file = new File(subFile, path + "_your_program.txt");
        if (!main_file.exists()) {
            Toast.makeText(this, "Not such file found", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            String str = "";
            text_editor_et.setText("");
            BufferedReader bf = new BufferedReader(new FileReader(main_file));
            while ((str = bf.readLine()) != null) {
                text_editor_et.append(str + '\n');
            }
        } catch (IOException e) {
            error_handler(this, e.getMessage());
        }
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.run_btn: {
                lock_texteditor = false;
                String code = text_editor_et.getText().toString().trim();
                if (code.isEmpty()) {
//                    Toast.makeText(this, "Please write some piece of code !", Toast.LENGTH_LONG).show();
//                    error_handler(this, "Please write some piece of code !");
                    error_text += "Please write some piece of code !\n";
                    error_handler(this, error_text);
                    error_text = "";
                    return;
                }
                executing(code);
                if (!error_returned) {
                    createExternalFile(new File(Environment.getExternalStorageDirectory(), "Miniature"), fileName_tv.getText().toString(), text_editor_et.getText().toString());
                }
                assembled_code = "";
                error_text = "";
                error_returned = false;
                directives.clear();
                labels.clear();
            }
            break;


        }
    }

    private void executing(String code) {
        try {
            String[] whole_code = code.split("\\n");
            List<String[]> all_lines = new ArrayList<>();
            List<String[]> all_lines_plus_directiveate = new ArrayList<>();
            String[] line;
            List<directivate_line_object> directivated_lines = new ArrayList<>();
            for (int i=0 ;i<whole_code.length;i++) {
                String s = whole_code[i] ;
                s = s.trim();
                if (s.matches("\\n")|| s.equals("")) {
                    continue;
                }
                if (s.contains("#")) {
                    StringBuilder sb = new StringBuilder(s);
                    sb.delete(sb.indexOf("#"), sb.length());
                    s = sb.toString();
                }
                s = s.toLowerCase();
                if (s.contains(".fill") || s.contains(".space")) {      //Directive
                    directivated_lines.add(new directivate_line_object(s, i));
                    all_lines_plus_directiveate.add(s.split("\\s+"));
                } else {                                                  //Un_directive
                    line = s.split("\\s+");
                    all_lines.add(line);
                    all_lines_plus_directiveate.add(line);
                }
            }
            labelMaking(all_lines_plus_directiveate);
            if (!error_returned) {
                directive_instruction_size = directivated_lines.size() ;
                for (directivate_line_object ss : directivated_lines) {
                    directive_format_scanner(ss);
                }
                for (int i = 0; i < all_lines.size(); i++) {
                    switch (all_lines.get(i)[0]) {
                        case ADDNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            R_type_handler(all_lines.get(i), ADD, false);
                        }
                        break;
                        case NANDNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            R_type_handler(all_lines.get(i), NAND, false);
                        }
                        break;
                        case ORNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            R_type_handler(all_lines.get(i), OR, false);
                        }
                        break;
                        case SLTNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            R_type_handler(all_lines.get(i), SLT, false);
                        }
                        break;
                        case SUBNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            R_type_handler(all_lines.get(i), SUB, false);
                        }
                        break;
                        case ADDINAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), ADDI, false);
                        }
                        break;
                        case BEQNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), BEQ, false);
                        }
                        break;
                        case JALRNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), JALR, false);
                        }
                        break;
                        case LUINAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), LUI, false);
                        }
                        break;
                        case LWNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), LW, false);
                        }
                        break;
                        case ORINAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), ORI, false);
                        }
                        break;
                        case SLTINAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), SLTI, false);
                        }
                        break;
                        case SWNAME: {
                            if (all_lines.get(i).length != 2) {
                                //ERROR
//                        Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                            error_handler(this, "Maybe you have not entered register field correctly !");
                                error_text += "Maybe you have not entered register field correctly !\n";
                                error_returned = true;
                                break;
                            }
                            I_type_handler(all_lines.get(i), SW, false);
                        }
                        break;
                        case HALTNAME: {
                            J_type_handler(all_lines.get(i), HALT, false);
                        }
                        break;
                        case JNAME: {
                            J_type_handler(all_lines.get(i), J, false);
                        }
                        break;
                        default: {
//                        if (all_lines.get(i).length < 2) {
////                        Toast.makeText(this, "You have entered only a label\nPlease write some piece of code !", Toast.LENGTH_LONG).show();
////                            error_handler(this, "You have entered only a label\nPlease write some piece of code !");
//                            error_text+="You have entered only a label.Please write some piece of code !\n";
//                            error_returned = true;
//                            break;
//                        }
//                        if (labels.contains(all_lines.get(i)[0])) {
//                            //ERROR
////                        Toast.makeText(this, "Duplicated label", Toast.LENGTH_LONG).show();
////                            error_handler(this, "Duplicated label");
//                            error_text+="Duplicated label\n";
//                            error_returned = true;
//                            break;
//                        }
//                        labels.add(all_lines.get(i)[0]);
                            switch (all_lines.get(i)[1]) {
                                case ADDNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    R_type_handler(all_lines.get(i), ADD, true);
                                }
                                break;
                                case NANDNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    R_type_handler(all_lines.get(i), NAND, true);
                                }
                                break;
                                case ORNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    R_type_handler(all_lines.get(i), OR, true);
                                }
                                break;
                                case SLTNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    R_type_handler(all_lines.get(i), SLT, true);
                                }
                                break;
                                case SUBNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    R_type_handler(all_lines.get(i), SUB, true);
                                }
                                break;
                                case ADDINAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), ADDI, true);
                                }
                                break;
                                case BEQNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), BEQ, true);
                                }
                                break;
                                case JALRNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), JALR, true);
                                }
                                break;
                                case LUINAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), LUI, true);
                                }
                                break;
                                case LWNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), LW, true);
                                }
                                break;
                                case ORINAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), ORI, true);
                                }
                                break;
                                case SLTINAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), SLTI, true);
                                }
                                break;
                                case SWNAME: {
                                    if (all_lines.get(i).length != 3) {
                                        //ERROR
//                                Toast.makeText(this,"ERROR\nMaybe you have not entered register field correctly !",Toast.LENGTH_LONG ).show();
//                                    error_handler(this, "Maybe you have not entered register field correctly !");
                                        error_text += "Maybe you have not entered register field correctly !\n";
                                        error_returned = true;
                                        break;
                                    }
                                    I_type_handler(all_lines.get(i), SW, true);
                                }
                                break;
                                case HALTNAME: {
                                    J_type_handler(all_lines.get(i), HALT, true);
                                }
                                break;
                                case JNAME: {
                                    J_type_handler(all_lines.get(i), J, true);
                                }
                                break;
                                default: {
                                    //ERROR
                                    error_text += "Not such instruction found !\n";
                                    error_returned = true;
                                }
                            }

                        }
                    }
                }
            }
            if (!error_returned) {
//                Toast.makeText(this, assembled_code, Toast.LENGTH_LONG).show();
                Intent i = new Intent(HomeActivity.this, ResultActivity.class);
                i.putExtra("result", assembled_code);
                i.putExtra("directive_size", directive_instruction_size) ;
                startActivity(i);
            } else
                error_handler(this, error_text);
        } catch (Exception e) {
            error_handler(this, e.getMessage());
//            throw e ;
        }
    }

    private void labelMaking(List<String[]> all_lines) {
        for (int i = 0; i < all_lines.size(); i++) {
            String [] line = all_lines.get(i) ;

            String str = line[0];
            if (!(str.equals(ADDNAME) || str.equals(NANDNAME) || str.equals(ORNAME) || str.equals(SLTNAME) || str.equals(SUBNAME) || str.equals(ADDINAME) ||
                    str.equals(BEQNAME) || str.equals(JALRNAME) || str.equals(LUINAME) || str.equals(LWNAME) || str.equals(ORINAME) || str.equals(SLTINAME) ||
                    str.equals(SWNAME) || str.equals(HALTNAME) || str.equals(JNAME))) {

                if (line.length < 2  ) {
                    error_text += "You have entered only a label.Please write some piece of code !\n";
                    text_editor_et.setText("mamad" );
                    error_returned = true;
                    return;
                }


                if (labels.containsKey(line[0])) {
                    error_text += "Duplicated label\n";
                    error_returned = true;
                    return;
                }
                labels.put(line[0], i);
            }
        }
    }

    private void directive_format_scanner(directivate_line_object str) {
        String[] stringArray = str.data.split("\\s+");

        if (stringArray.length==3) {
                if ( !(stringArray[1].equals(".fill") || stringArray[1].equals(".space")) ) {
                    error_text += "Wrong directive format!\n";
                    error_returned = true;
                    return;
                }
                if (labels.containsKey(stringArray[2])) {
//                    String myString = to_4_digit_binary_number("0000", String.valueOf(labels.get(stringArray[2])));
                    String myString = String.valueOf(labels.get(stringArray[2]));
//                    myString = new BigInteger(myString, 2).toString();
                    if (stringArray[1].equals(".fill")) {
                        ram[str.line_number] = myString;
                        ram_used[str.line_number]++;
                    }
                    myString += '\n';
                    assembled_code += myString;
                    return;
                }
                if ((stringArray[1].equals(".fill")&&stringArray[2].matches(POS_NEG_NUMERIC_REGIX))   ||
                    (stringArray[1].equals(".space")&&stringArray[2].matches(POSITIVE_NUMERIC_REGIX))) {
                    String myString = stringArray[2] ;
//                    String myString = to_4_digit_binary_number("0000", stringArray[2]);
//                    myString = new BigInteger(myString, 2).toString();
                    if (stringArray[1].equals(".fill")) {
                        ram[str.line_number] = myString;
                        ram_used[str.line_number] ++ ;
                    }
                    else if (stringArray[1].equals(".space"))
                    {
                        int from = str.line_number ;
                        int to = from + Integer.valueOf(stringArray[2]);
                        for (int i = from ; i<to ;i++) {
                            ram[i] = "0";
                            ram_used[i] ++;
                        }
                    }
                    myString += '\n';
                    assembled_code += myString;
                    return;
                }
                error_text += (stringArray[2] + " is invalid!");
                error_returned = true;

        }

        if (stringArray.length==2)
        {
            if ( !(stringArray[0].equals(".fill") || stringArray[0].equals(".space")) ) {
                error_text += "Wrong directive format!\n";
                error_returned = true;
                return;
            }
            if (labels.containsKey(stringArray[1])) {
                String myString =  String.valueOf(labels.get(stringArray[1])) ;
//                String myString = to_4_digit_binary_number("0000", String.valueOf(labels.get(stringArray[1])));
//                myString = new BigInteger(myString, 2).toString();
                if(stringArray[0].equals(".fill")) {
                    ram[str.line_number] = myString;
                    ram_used[str.line_number]++;
                }
                myString += '\n';
                assembled_code += myString;
                return;
            }
            if ((stringArray[0].equals(".fill")&&stringArray[1].matches(POS_NEG_NUMERIC_REGIX))   ||
                    (stringArray[0].equals(".space")&&stringArray[1].matches(POSITIVE_NUMERIC_REGIX))) {
                String myString = stringArray[1] ;
                if (stringArray[0].equals(".fill")) {
                    ram[str.line_number] = myString;
                    ram_used[str.line_number]++;
                }
                else if (stringArray[0].equals(".space"))
                {
                    int from = str.line_number ;
                    int to = from + Integer.valueOf(stringArray[1]);
                    for (int i = from ; i<to ;i++) {
                        ram[i] = "0";
                        ram_used[i]++;
                    }
                }
                myString += '\n';
                assembled_code += myString;
                return;
            }
            error_text += (stringArray[1] + " is invalid!");
            error_returned = true;
        }
        error_text += "Wrong directive format!\n";
        error_returned = true;

    }

    private void J_type_handler(String[] arrayString, String opcode, boolean hasLabel) {
        J_Type ins = new J_Type();
        ins.opcode = opcode;
        if (hasLabel) {
            if (opcode.equals(J)) {
                if (arrayString.length != 3) {
                    //ERROR
//                    error_handler(this, "Register field in J instruction must contain only one part!");
                    error_text += "Register field in J instruction must contain only one part!\n";
                    error_returned = true;
                    return;
                }
                if (labels.containsKey(arrayString[2])) {
                    ins.target = String.valueOf(labels.get(arrayString[2]));
//                    if (Integer.parseInt(ins.target)>65535)
//                    {
//                        error_text+="This offset is more than 16 bits!\n";
//                        error_returned=true;
//                        return;
//                    }
                }
                else if (arrayString[2].matches(POSITIVE_NUMERIC_REGIX))
                {
                    ins.target = arrayString[2];
                    if (Integer.parseInt(ins.target)>65535)
                    {
                        error_text+="This offset is more than 16 bits!\n";
                        error_returned=true;
                        return;
                    }
                }
                else {
                    error_text += "Target field is invalid!\n";
                    error_returned = true;
                    return;
                }
                if (lock_texteditor)
                    return;
                assembled_code += ins.toString();
            } else if (opcode.equals(HALT)) {
                if (arrayString.length != 2) {
                    //ERROR
                    error_text += "Register field in HALT instruction must be empty!\n";
                    error_returned = true;
                    return;
                }
                assembled_code += "234881024\n";
                lock_texteditor = true;
            }
        } else {
            if (opcode.equals(J)) {
                if (arrayString.length != 2) {
                    error_text += "Register field in J instruction must contain only one part!\n";
                    error_returned = true;
                    return;
                }
                if (labels.containsKey(arrayString[1])) {
                    ins.target = String.valueOf(labels.get(arrayString[1]));
//                    if (Integer.parseInt(ins.target)>65535)
//                    {
//                        //ERROR
//                        error_text+="This offset is more than 16 bits!\n";
//                        error_returned=true;
//                        return;
//                    }
                }
                else if (arrayString[1].matches(POSITIVE_NUMERIC_REGIX))
                {
                    ins.target = arrayString[1];
                    if (Integer.parseInt(ins.target)>65535)
                    {
                        //ERROR
                        error_text+="This offset is more than 16 bits!\n";
                        error_returned=true;
                        return;
                    }
                }
                else {
                    //ERROR
                    error_text += "Target field is invalid!\n";
                    error_returned = true;
                    return;
                }
                if (lock_texteditor)
                    return;
                assembled_code += ins.toString();
            } else if (opcode.equals(HALT)) {
                if (arrayString.length != 1) {
                    //ERROR
                    error_text += "Register field in HALT instruction must be empty!\n";
                    error_returned = true;
                    return;
                }
                assembled_code += "234881024\n";
                lock_texteditor = true;
            }
        }
    }

    private void I_type_handler(String[] arrayString, String opcode, boolean hasLabel) {
        I_Type ins = new I_Type();
        ins.opcode = opcode;
        if (hasLabel) {
            if (arrayString.length != 3) {
                //ERROR
//                error_handler(this, "Incorrect instruction format !");
                error_text += "Incorrect instruction format !\n";
                error_returned = true;
                return;
            }
            String[] registers = arrayString[2].split(",");


            if (opcode.equals(LUI)) {
                if (registers.length != 2) {
                    //ERROR
//                    error_handler(this, "Register field in LUI instruction must contains only two parts!");
                    error_text += "Register field in LUI instruction must contains only two parts!\n";
                    error_returned = true;
                    return;
                }
                ins.rs = "0000";
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
                        error_handler(this, "There are only 16 registers!");
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[1])) {
                    ins.offset = directives.get(registers[1]);
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POS_NEG_NUMERIC_REGIX)) {
                    ins.offset = registers[1];
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "offset field is invalid!");
                    error_text += "offset field is invalid!\n";
                    error_returned = true;
                    return;
                }
            } else if (opcode.equals(JALR)) {
                if (registers.length != 2) {
                    //ERROR
//                    error_handler(this, "Register field in JALR instruction must contains only two parts!");
                    error_text += "Register field in JALR instruction must contains only two parts!\n";
                    error_returned = true;
                    return;
                }
                ins.offset = "0000000000000000";
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[1])) {
                    ins.rs = directives.get(registers[1]);

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rs = registers[1];

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rs register is invalid!");
                    error_text += "rs register is invalid!\n";
                    error_returned = true;
                    return;
                }
            } else {
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }

                if (directives.containsKey(registers[1])) {
                    ins.rs = directives.get(registers[1]);

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rs = registers[1];

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rs register is invalid!");
                    error_text += "rs register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[2])) {
                    ins.offset = directives.get(registers[2]);
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else if (labels.containsKey(registers[2])) {
                    ins.offset = String.valueOf(labels.get(registers[2]));
                } else if (registers[2].matches(POS_NEG_NUMERIC_REGIX)) {
                    ins.offset = registers[2];
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "offset field is invalid!");
                    error_text += "offset field is invalid!\n";
                    error_returned = true;
                    return;
                }
            }
        } else {
            if (arrayString.length != 2) {
                //ERROR
                error_handler(this, "Incorrect instruction format !");
                error_returned = true;
                return;
            }
            String[] registers = arrayString[1].split(",");


            if (opcode.equals(LUI)) {
                if (registers.length != 2) {
                    //ERROR
//                    error_handler(this, "Register field in LUI instruction must contains only two parts!");
                    error_text += "Register field in LUI instruction must contains only two parts!\n";
                    error_returned = true;
                    return;
                }
                ins.rs = "0000";
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
                        error_handler(this, "There are only 16 registers!");
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[1])) {
                    ins.offset = directives.get(registers[1]);
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POS_NEG_NUMERIC_REGIX)) {
                    ins.offset = registers[1];
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "offset field is invalid!");
                    error_text += "offset field is invalid!\n";
                    error_returned = true;
                    return;
                }
            } else if (opcode.equals(JALR)) {
                if (registers.length != 2) {
                    //ERROR
//                    error_handler(this, "Register field in JALR instruction must contains only two parts!");
                    error_text += "Register field in JALR instruction must contains only two parts!\n";
                    error_returned = true;
                    return;
                }
                ins.offset = "0000000000000000";
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[1])) {
                    ins.rs = directives.get(registers[1]);

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rs = registers[1];

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rs register is invalid!");
                    error_text += "rs register is invalid!\n";
                    error_returned = true;
                    return;
                }
            } else {
                if (directives.containsKey(registers[0])) {
                    ins.rt = directives.get(registers[0]);

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rt = registers[0];

                    if (Integer.parseInt(ins.rt) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rt register is invalid!");
                    error_text += "rt register is invalid!\n";
                    error_returned = true;
                    return;
                }

                if (directives.containsKey(registers[1])) {
                    ins.rs = directives.get(registers[1]);

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                    ins.rs = registers[1];

                    if (Integer.parseInt(ins.rs) > 15) {
//                        error_handler(this, "There are only 16 registers!");
                        error_text += "There are only 16 registers!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "rs register is invalid!");
                    error_text += "rs register is invalid!\n";
                    error_returned = true;
                    return;
                }


                if (directives.containsKey(registers[2])) {
                    ins.offset = directives.get(registers[2]);
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else if (labels.containsKey(registers[2])) {
                    ins.offset = String.valueOf(labels.get(registers[2]));
                } else if (registers[2].matches(POS_NEG_NUMERIC_REGIX)) {
                    ins.offset = registers[2];
                    if (Integer.parseInt(ins.offset) > 65535) {
//                        error_handler(this, "This offset is more than 16 bits!");
                        error_text += "This offset is more than 16 bits!\n";
                        error_returned = true;
                        return;
                    }
                } else {
//                    error_handler(this, "offset field is invalid!");
                    error_text += "offset field is invalid!\n";
                    error_returned = true;
                    return;
                }
            }
        }
        if (lock_texteditor)
            return;
        assembled_code += ins.toString();
    }

    private void R_type_handler(String[] arrayString, String opcode_name, boolean hasLabel) {
        R_Type ins = new R_Type();
        ins.opcode = opcode_name;
        if (hasLabel) {
            if (arrayString.length != 3) {
                //ERROR
//                Toast.makeText(this, "Incorrect instruction format !", Toast.LENGTH_LONG).show();
//                error_handler(this, "Incorrect instruction format !");
                error_text += "Incorrect instruction format !\n";
                error_returned = true;
                return;
            }
            String[] registers = arrayString[2].split(",");
            if (directives.containsKey(registers[0])) {
                ins.rd = directives.get(registers[0]);
                if (Integer.parseInt(ins.rd) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }

            } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rd = registers[0];
                if (Integer.parseInt(ins.rd) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }

            } else {
//                error_handler(this, "rd register is invalid!");
                error_text += "rd register is invalid!\n";
                error_returned = true;
                return;
            }

            if (directives.containsKey(registers[1])) {
                ins.rs = directives.get(registers[1]);
                if (Integer.parseInt(ins.rs) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rs = registers[1];
                if (Integer.parseInt(ins.rs) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else {
//                error_handler(this, "rs register is invalid!");
                error_text += "rs register is invalid!\n";
                error_returned = true;
                return;
            }

            if (directives.containsKey(registers[2])) {
                ins.rt = directives.get(registers[2]);
                if (Integer.parseInt(ins.rt) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else if (registers[2].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rt = registers[2];
                if (Integer.parseInt(ins.rt) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else {
//                error_handler(this, "rt register is invalid!");
                error_text += "rt register is invalid!\n";
                error_returned = true;
                return;
            }
        } else {
            if (arrayString.length != 2) {
                //error
//                Toast.makeText(this, "Incorrect instruction format !", Toast.LENGTH_LONG).show();
//                error_handler(this, "Incorrect instruction format !");
                error_text += "Incorrect instruction format !\n";
                error_returned = true;
                return;
            }
            String[] registers = arrayString[1].split(",");
            if (directives.containsKey(registers[0])) {
                ins.rd = directives.get(registers[0]);
                if (Integer.parseInt(ins.rd) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }

            } else if (registers[0].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rd = registers[0];
                if (Integer.parseInt(ins.rd) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }

            } else {
//                error_handler(this, "rd register is invalid!");
                error_text += "rd register is invalid!\n";
                error_returned = true;
                return;
            }

            if (directives.containsKey(registers[1])) {
                ins.rs = directives.get(registers[1]);
                if (Integer.parseInt(ins.rs) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else if (registers[1].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rs = registers[1];
                if (Integer.parseInt(ins.rs) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else {
//                error_handler(this, "rs register is invalid!");
                error_text += "rs register is invalid!\n";
                error_returned = true;
                return;
            }

            if (directives.containsKey(registers[2])) {
                ins.rt = directives.get(registers[2]);
                if (Integer.parseInt(ins.rt) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else if (registers[2].matches(POSITIVE_NUMERIC_REGIX)) {
                ins.rt = registers[2];
                if (Integer.parseInt(ins.rt) > 15) {
//                    error_handler(this, "There is only 16 registers!");
                    error_text += "There is only 16 registers!\n";
                    error_returned = true;
                    return;
                }
            } else {
//                error_handler(this, "rt register is invalid!");
                error_text += "rt register is invalid!\n";
                error_returned = true;
                return;
            }

        }
        if (lock_texteditor)
            return;
        assembled_code += ins.toString();
    }

    private void error_handler(Context context, String error_message) {
        if (error_message.contains("\n"))
            error_message = new StringBuilder(error_message).delete(error_message.lastIndexOf('\n'), error_message.length()).toString();
        View view = getLayoutInflater().inflate(R.layout.error_layout, null);
        final Dialog error_dialog = new Dialog(context);
        error_dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        error_dialog.setContentView(view);
        error_dialog.setCancelable(false);
        ((TextView) view.findViewById(R.id.error_tv)).setText(error_message);
        (view.findViewById(R.id.back_to_code_btn)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                error_dialog.dismiss();
            }
        });
        error_dialog.show();
    }

    public static String to_4_digit_binary_number(String format, String number) {
        int integer = Integer.valueOf(number);
        number = Integer.toBinaryString(integer);

        if (number.length()==format.length())
            return number ;
        if (number.length()==32)
        {
            number = number.substring(16, 32);
            return number ;
        }

        int size = number.length() ;
        StringBuilder sb = new StringBuilder(number) ;
        for (int i=0 ;i<format.length()-size ;i ++)
        {
            sb.insert(0, '0') ;
        }

        return sb.toString();

    }

    private void createExternalFile(File dir, String fileName, String content) {
        if (!dir.exists())
            dir.mkdirs();
        File subdir = new File(dir, fileName);
        if (!subdir.exists())
            subdir.mkdirs();
        File f = new File(subdir, fileName + "_your_program.txt");
        try {
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(content.getBytes());
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        f = new File(subdir, fileName + "_assembled_code.txt");

        try {
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(assembled_code.getBytes());
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public class directivate_line_object {
        public String data ;
        public int line_number ;

        public directivate_line_object(String data, int line_number) {
            this.data = data;
            this.line_number = line_number;
        }
    }
}
